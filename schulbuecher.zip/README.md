# schulbuecher
Hier können bestimmte Problemstellungen und Lösungen gesammelt und diskutiert werden

Zum Start wurde eine Themensammlung erstellt
